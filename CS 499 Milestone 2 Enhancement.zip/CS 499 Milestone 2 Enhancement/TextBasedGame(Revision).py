# Logan Schlesselman
# Refactored Text-Based Adventure Game: Skeleton Dungeon of Doom

import sys

# --- Game Data Structure ---
# Refactored 'rooms' dictionary to be data-driven.
# Each room now contains:
# 'Exits': A dictionary of possible movement directions (key) and the target room (value).
# 'Item': A dictionary containing the item's details, or None if no item is present.
#   - 'name': The item's actual name.
#   - 'prompt': The specific text prompt when entering the room with the item.
#   - 'success': The text displayed when the player successfully takes the item.
# Commands/items/interactive words are indicated as follows: **(Example)**
ROOMS = {
    'Swamp': {
        'Exits': {'North': 'Dining Room', 'East': 'Garden'},
        'Item': {'name': 'Toad',
                 'prompt': 'You arrive at a disgustingly smelly and damp swamp. There is a **Toad** asleep on a rock. Type "get Toad" to disturb its slumber.',
                 'success': 'You quickly snatch the Toad.'}
    },
    'Dungeon Cave Entrance': {
        'Exits': {'East': 'Dining Room'},
        'Item': None
    },
    'Garden': {
        'Exits': {'West': 'Swamp'},
        'Item': {'name': 'Mandrake Root',
                 'prompt': 'There is a strange **Mandrake Root** sticking out of the ground. Type "get Mandrake Root" to dare and pull it.',
                 'success': 'You take the strange root. To your surprise, it is alive! You quickly put it inside your bag.'}
    },
    'Grand Hall': {
        'Exits': {'East': 'Observatory', 'South': 'Dining Room'},
        'Item': {'name': 'Ruby',
                 'prompt': 'You hear the rattling of bones in the distance... You notice a **Ruby** embedded into a painting of a skeleton in a throne. Type "get Ruby" to take it.',
                 'success': 'You take the Ruby from the painting... What is a painting of a skeleton doing here anyway?'}
    },
    'Observatory': {  # Villain Room
        'Exits': {'West': 'Grand Hall'},
        'Item': None
    },
    'Abandoned Lab': {
        'Exits': {'North': 'Great Library', 'West': 'Dining Room'},
        'Item': {'name': 'Rabbits Foot',
                 'prompt': 'There is a **Rabbits Foot** in a jar. Type "get Rabbits Foot" to take it.',
                 'success': 'You take the Rabbits Foot, hoping it will bring you luck, despite your current ordeal.'}
    },
    'Great Library': {
        'Exits': {'South': 'Abandoned Lab'},
        'Item': {'name': 'Spell Book',
                 'prompt': 'You arrive at a ginormous library, it seems to go on forever. Want to take a **Spell Book**? Type "get Spell Book".',
                 'success': 'You read the cover. It seems to be an old book for casting spells. Very handy to vanquish evil, best to get out of here while you still can...'}
    },
    'Dining Room': {
        'Exits': {'West': 'Dungeon Cave Entrance', 'North': 'Grand Hall', 'East': 'Abandoned Lab', 'South': 'Swamp'},
        'Item': {'name': 'Golden Goblet',
                 'prompt': 'You arrive to an extravagant dining room. There is a **Golden Goblet** on the table. Type "get Golden Goblet" to take it.',
                 'success': 'You take the Golden Goblet, embedded with various valuable gems. It could prove useful in carrying a potent elixir...'}
    }
}

WIN_CONDITION_ITEMS = 6
STARTING_ROOM = 'Dungeon Cave Entrance'


# --- Helper Functions ---

def show_instructions():
    """Prints the game title, goal, and available commands."""
    print("================================")
    print("💀 Skeleton Dungeon of Doom 💀")
    print("================================")
    print("Collect **{}items** to win the game and save the princess!".format(WIN_CONDITION_ITEMS))
    print("--------------------------------")
    print("Move Commands: go [North/South/East/West]")
    print("Item Command: get [item name]")
    print("Other Commands: help, exit")
    print("--------------------------------")


def show_status(current_room, inventory):
    """
    Prints the player's current status, including their location and inventory.
    Also prints the room's custom item prompt if an item is present.
    """
    print('\n------------------------')
    print('You are currently in **{}**'.format(current_room))
    print('Your current inventory: {}'.format(inventory))

    # Display the specific room-based prompt if an item is available
    room_data = ROOMS[current_room]
    if room_data['Item'] and room_data['Item']['name'] not in inventory:
        print(room_data['Item']['prompt'])
    print('------------------------')


def handle_item_interaction(current_room, inventory, command_parts):
    """
    Handles the 'get [item name]' command.
    Checks if the requested item is in the room and not already in the inventory.
    If valid, adds the item to the inventory and prints the success message.

    Args:
        current_room (str): The player's current location.
        inventory (list): The player's current item list.
        command_parts (list): The list of words from the player's input command.

    Returns:
        bool: True if an item interaction occurred, False otherwise.
    """
    room_data = ROOMS[current_room]

    # 1. Check if the current room even has an item
    if not room_data['Item']:
        print("There is nothing to take in this area.")
        return True  # Handled the item command, but no item was present

    item_name = room_data['Item']['name']

    # 2. Check if the player is trying to get the right item
    requested_item = ' '.join(command_parts[1:]).strip()
    if requested_item.lower() != item_name.lower():
        print(f"You can't get that here. The item is the **{item_name}**.")
        return True  # Handled an item command, but wrong item name

    # 3. Check if the item is already in the inventory
    if item_name in inventory:
        print(f"You already have the **{item_name}**.")
        return True

    # 4. Successful item collection
    inventory.append(item_name)
    print(room_data['Item']['success'])
    return True


def handle_movement(current_room, command_parts):
    """
    Handles the 'go [direction]' command.
    Updates the player's room if the exit is valid.

    Args:
        current_room (str): The player's current location.
        command_parts (list): The list of words from the player's input command.

    Returns:
        str: The new room name if a move occurred, otherwise the current_room name.
    """
    if len(command_parts) < 2:
        print("Where do you want to go? Use 'go North', 'go South', etc.")
        return current_room

    direction = command_parts[1].capitalize()

    # Check if the direction is a valid exit from the current room
    if direction in ROOMS[current_room]['Exits']:
        new_room = ROOMS[current_room]['Exits'][direction]
        return new_room
    else:
        print(f"You can't go **{direction}** from here.")
        return current_room


# --- Main Game Loop ---
def play_game():
    """The main function containing the game loop."""
    current_room = STARTING_ROOM
    inventory = []

    show_instructions()

    while True:
        # 1. Check Win/Loss Conditions
        if current_room == 'Observatory':
            if len(inventory) == WIN_CONDITION_ITEMS:
                print('\n************************************************************************')
                print('With your **{} ingredients** in hand, you craft a potent potion able to slay evil!'.format(
                    WIN_CONDITION_ITEMS))
                print('You defeat the skeleton easily and are able to save the princess.')
                print('Your quest has been fulfilled! 👑')
                print('************************************************************************')
                sys.exit(0)  # Exit the game
            else:
                print('\n************************************************************************')
                print('You enter the grand observatory. A giant skeleton stands between you and the princess!')
                print('You only have {} items. Before you knew it, the grand skeleton crushed you!'.format(
                    len(inventory)))
                print('Your quest has ended, and you, nor the princess, are ever heard from again.')
                print('************************************************************************')
                sys.exit(0)  # Exit the game

        # 2. Display Status and Get Input
        show_status(current_room, inventory)

        user_input = input('What is your next command? (e.g., go North, get Ruby, exit): ').strip()
        command_parts = user_input.lower().split()

        if not command_parts:
            print("Invalid command. Type 'help' to see instructions.")
            continue

        command = command_parts[0]

        # 3. Process Command
        print('------------------------')

        if command == 'exit':
            print('You decide to leave the dungeon. The princess is left behind, and your story goes untold.')
            break

        elif command == 'help':
            show_instructions()

        elif command == 'go':
            # Handle movement command
            current_room = handle_movement(current_room, command_parts)

        elif command == 'get':
            # Handle item collection command
            handle_item_interaction(current_room, inventory, command_parts)

        else:
            print('Invalid command. Type "help" to see valid commands.')


# --- Program Entry Point ---
if __name__ == '__main__':
    play_game()